import pickle
import sys

# from PyQt5.QtGui import QPixmap
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QImageReader
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QFileDialog
from PyQt5.Qt import QPixmap, QPoint, Qt, QPainter, QIcon
from PyQt5.QtCore import QSize

# test_designed是文件名
import inter_designed
from PyQt5.QtWidgets import QApplication, QMainWindow
from qt_material import apply_stylesheet
from inter_designed import Ui_MainWindow
import networkx as nx
from utils import *


class ImageBox(QWidget):
    def __init__(self):
        super(ImageBox, self).__init__()
        self.img = None
        self.scaled_img = None
        self.start_pos = None
        self.end_pos = None
        self.left_click = False
        self.wheel_flag = False

        self.scale = 1
        self.old_scale = 1
        self.point = QPoint(0, 0)
        self.x = -1
        self.y = -1
        self.new_height = -1
        self.new_width = -1

    def init_ui(self):
        self.setWindowTitle("ImageBox")

    def set_image(self, img_path):
        self.img = QPixmap(img_path)
        width, height = self.img.width(), self.img.height()
        if height / width > 600 / 800:
            new_height = 600
            new_width = width * 600 / height
        else:
            new_height = height * 800 / width
            new_width = 800
        self.point = QPoint(int((600 - new_width) * 0.5), int((800 - new_height) * 0.5))
        self.img = self.img.scaled(new_width, new_height, Qt.KeepAspectRatio)
        self.scaled_img = self.img

        self.new_height = new_height
        self.new_width = new_width
        self.scale = 1
        print(new_height, new_width)

    def paintEvent(self, e):
        if self.scaled_img:
            painter = QPainter()
            painter.begin(self)
            painter.scale(self.scale, self.scale)
            if self.wheel_flag:  # 定点缩放
                self.wheel_flag = False
                # 判断当前鼠标pos在不在图上
                this_left_x = self.point.x() * self.old_scale
                this_left_y = self.point.y() * self.old_scale
                this_scale_width = self.new_width * self.old_scale
                this_scale_height = self.new_height * self.old_scale

                # 鼠标点在图上，以鼠标点为中心动作
                gap_x = self.x - this_left_x
                gap_y = self.y - this_left_y
                if 0 < gap_x < this_scale_width and 0 < gap_y < this_scale_height:
                    new_left_x = int(self.x / self.scale - gap_x / self.old_scale)
                    new_left_y = int(self.y / self.scale - gap_y / self.old_scale)
                    self.point = QPoint(new_left_x, new_left_y)
                # 鼠标点不在图上，固定左上角进行缩放
                else:
                    true_left_x = int(self.point.x() * self.old_scale / self.scale)
                    true_left_y = int(self.point.y() * self.old_scale / self.scale)
                    self.point = QPoint(true_left_x, true_left_y)
            painter.drawPixmap(self.point, self.scaled_img)  # 此函数中还会用scale对point进行处理
            painter.end()

    def wheelEvent(self, event):
        angle = event.angleDelta() / 8  # 返回QPoint对象，为滚轮转过的数值，单位为1/8度
        angleY = angle.y()
        self.old_scale = self.scale
        self.x, self.y = event.x(), event.y()
        self.wheel_flag = True
        # 获取当前鼠标相对于view的位置
        if angleY > 0:
            self.scale *= 1.08
        else:  # 滚轮下滚
            self.scale *= 0.92
        if self.scale < 0.3:
            self.scale = 0.3
        self.adjustSize()
        self.update()

    def mouseMoveEvent(self, e):
        if self.left_click:
            self.end_pos = e.pos() - self.start_pos  # 当前位置-起始位置=差值
            self.point = self.point + self.end_pos / self.scale  # 左上角的距离变化
            self.start_pos = e.pos()
            self.repaint()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.left_click = True
            self.start_pos = e.pos()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.left_click = False


class MyMainWindow(QMainWindow, Ui_MainWindow):  # 继承 QMainWindow类和 Ui_MainWindow界面类
    def __init__(self, parent=None):
        super(MyMainWindow, self).__init__(parent)  # 初始化父类
        # self.SearchButton.setProperty('class', 'Search')

        G = nx.read_gml(f'gml/t11_6.gml')
        self.num_nodes = 145 # getNumNodes(G)
        self.num_edges = 2229 # getNumEdges(G)
        self.average_degree = 15.37 # getAverageDegree(G)
        # self.shortest_path_lengths, self.shortest_paths, self.average_shortest_path_length = getShortestPath(G)
        with open(f'results/shortest_11_6.pkl', 'rb') as f:
            self.shortest_path_lengths, self.shortest_paths, self.average_shortest_path_length = pickle.load(f)
        self.coreness = 21 # getCoreness(G)
        self.average_clustering_coefficient = 0.2867 #getAverageClusteringCoefficient(G)
        self.assortativity_coefficient = 0.07868 # getAssortativityCoefficient(G)

        G2 = nx.read_gml(f'gml/t11_3.gml')
        self.num_nodes_2 = 195 # getNumNodes(G2)
        self.num_edges_2 = 3885 # getNumEdges(G2)
        self.average_degree_2 = 19.92 # getAverageDegree(G2)
        # self.shortest_path_lengths_2, self.shortest_paths_2, self.average_shortest_path_length_2 = getShortestPath(G2)
        with open(f'results/shortest_11_3.pkl', 'rb') as f:
            self.shortest_path_lengths_2, self.shortest_paths_2, self.average_shortest_path_length_2 = pickle.load(f)
        self.coreness_2 = 29 # getCoreness(G2)
        self.average_clustering_coefficient_2 = 0.4316 # getAverageClusteringCoefficient(G2)
        self.assortativity_coefficient_2 = -0.156 # getAssortativityCoefficient(G2)

        G3 = nx.read_gml(f'gml/t11_5.gml')
        self.num_nodes_3 = 246 # getNumNodes(G3)
        self.num_edges_3 = 4117 # getNumEdges(G3)
        self.average_degree_3 = 16.74 # getAverageDegree(G3)
        # self.shortest_path_lengths_3, self.shortest_paths_3, self.average_shortest_path_length_3 = getShortestPath(G3)
        with open(f'results/shortest_11_5.pkl', 'rb') as f:
            self.shortest_path_lengths_3, self.shortest_paths_3, self.average_shortest_path_length_3 = pickle.load(f)
        self.coreness_3 = 25 # getCoreness(G3)
        self.average_clustering_coefficient_3 = 0.5086 # getAverageClusteringCoefficient(G3)
        self.assortativity_coefficient_3 = -0.06627 # getAssortativityCoefficient(G3)

        G4 = nx.read_gml(f'gml/t6.gml')
        self.num_nodes_4 = 534 # getNumNodes(G4)
        self.num_edges_4 = 12812 # getNumEdges(G4)
        self.average_degree_4 = 23.99 # getAverageDegree(G4)
        # self.shortest_path_lengths_4, self.shortest_paths_4, self.average_shortest_path_length_4 = getShortestPath(G4)
        with open(f'results/shortest_6.pkl', 'rb') as f:
            self.shortest_path_lengths_4, self.shortest_paths_4, self.average_shortest_path_length_4 = pickle.load(f)
        self.coreness_4 = 36 # getCoreness(G4)
        self.average_clustering_coefficient_4 = 0.4266 # getAverageClusteringCoefficient(G4)
        self.assortativity_coefficient_4 = -0.03315 # getAssortativityCoefficient(G4)

        # self.average_shortest_path_length = 1.0
        # self.average_shortest_path_length_2 = 1.0
        # self.average_shortest_path_length_3 = 1.0
        # self.average_shortest_path_length_4 = 1.0


        self.setupUi(self)  # 继承 Ui_MainWindow 界面类
        # print(self.label.getFont())
        # print(self.label_8.getFont())
        # network1
        self.nodes_text.setText(str(self.num_nodes))
        self.edges_text.setText(str(self.num_edges))
        self.average_degree_text.setText("{:.4}".format(self.average_degree))
        self.average_shortest_path_length_text.setText(("{:.4}".format(self.average_shortest_path_length)))
        self.coreness_text.setText((str(self.coreness)))
        self.average_clustering_coefficient_text.setText("{:.4}".format(self.average_clustering_coefficient))
        self.assortativity_coefficient_text.setText(("{:.4}".format(self.assortativity_coefficient)))
        # network2
        self.nodes_text_2.setText(str(self.num_nodes_2))
        self.edges_text_2.setText(str(self.num_edges_2))
        self.average_degree_text_2.setText("{:.4}".format(self.average_degree_2))
        self.average_shortest_path_length_text_2.setText(("{:.4}".format(self.average_shortest_path_length_2)))
        self.coreness_text_2.setText((str(self.coreness_2)))
        self.average_clustering_coefficient_text_2.setText("{:.4}".format(self.average_clustering_coefficient_2))
        self.assortativity_coefficient_text_2.setText(("{:.4}".format(self.assortativity_coefficient_2)))
        # network3
        self.nodes_text_3.setText(str(self.num_nodes_3))
        self.edges_text_3.setText(str(self.num_edges_3))
        self.average_degree_text_3.setText("{:.4}".format(self.average_degree_3))
        self.average_shortest_path_length_text_3.setText(("{:.4}".format(self.average_shortest_path_length_3)))
        self.coreness_text_3.setText((str(self.coreness_3)))
        self.average_clustering_coefficient_text_3.setText("{:.4}".format(self.average_clustering_coefficient_3))
        self.assortativity_coefficient_text_3.setText(("{:.4}".format(self.assortativity_coefficient_3)))
        # network4
        self.nodes_text_4.setText(str(self.num_nodes_4))
        self.edges_text_4.setText(str(self.num_edges_4))
        self.average_degree_text_4.setText("{:.4}".format(self.average_degree_4))
        self.average_shortest_path_length_text_4.setText(("{:.4}".format(self.average_shortest_path_length_4)))
        self.coreness_text_4.setText((str(self.coreness_4)))
        self.average_clustering_coefficient_text_4.setText("{:.4}".format(self.average_clustering_coefficient_4))
        self.assortativity_coefficient_text_4.setText(("{:.4}".format(self.assortativity_coefficient_4)))

        self.path = 'D:\\Desktop\\fig\\'

        self.tabWidget.setStyleSheet('''QTabBar::tab{width:220px; height:35px; border-top-left-radius:5px; border-top-right-radius:5px; font:25px; padding:4px; margin:5px; background-color:white;}
        font:20px''')

        self.fig.setStyleSheet("border-image: url(fig/11_6/degree_distribution.png);")
        self.fig_2.setStyleSheet("border-image: url(fig/11_3/degree_distribution.png);")
        self.fig_3.setStyleSheet("border-image: url(fig/11_5/degree_distribution.png);")
        self.fig_4.setStyleSheet("border-image: url(fig/6/degree_distribution.png);")

        self.box = ImageBox()
        self.box_2 = ImageBox()
        self.box_3 = ImageBox()
        self.box_4 = ImageBox()

        self.gridLayout_2.addWidget(self.box, 0, 0, 1, 1)
        img_name = 'fig/11_6.png'
        self.box.set_image(img_name)
        self.gridLayout_3.addWidget(self.box_2, 0, 0, 1, 1)
        img_name_2 = 'fig/11_3.png'
        self.box_2.set_image(img_name_2)
        self.gridLayout_4.addWidget(self.box_3, 0, 0, 1, 1)
        img_name_3 = 'fig/11_5.png'
        self.box_3.set_image(img_name_3)
        self.gridLayout_5.addWidget(self.box_4, 0, 0, 1, 1)
        img_name_4 = 'fig/6.png'
        self.box_4.set_image(img_name_4)



    def show_fig(self):
        fig = self.comboBox.currentText()
        fig = fig.replace(' ', '_').lower()
        self.fig.setStyleSheet(f"border-image: url(fig/11_6/{fig}.png);")

    def show_fig_2(self):
        fig = self.comboBox_2.currentText()
        fig = fig.replace(' ', '_').lower()
        self.fig_2.setStyleSheet(f"border-image: url(fig/11_3/{fig}.png);")

    def show_fig_3(self):
        fig = self.comboBox_3.currentText()
        fig = fig.replace(' ', '_').lower()
        self.fig_3.setStyleSheet(f"border-image: url(fig/11_5/{fig}.png);")

    def show_fig_4(self):
        fig = self.comboBox_4.currentText()
        fig = fig.replace(' ', '_').lower()
        self.fig_4.setStyleSheet(f"border-image: url(fig/6/{fig}.png);")

    def click_search(self):
        if self.start_edit.text().isdigit()==False or self.end_edit.text().isdigit()==False:
            self.shortest_path_length_text.setText('')
            self.shortest_path_text.setText('')
            return
        start = int(self.start_edit.text())
        end = int(self.end_edit.text())
        if start >= self.num_nodes or end >= self.num_nodes:
            self.shortest_path_length_text.setText('')
            self.shortest_path_text.setText('')
            return
        if self.shortest_path_lengths[start, end] == float('inf'):
            length = 'inf'
            self.shortest_path_length_text.setText(str(length))
            self.shortest_path_text.setText('NO PATH')
        else:
            length = int(self.shortest_path_lengths[start, end])
            self.shortest_path_length_text.setText(str(length))
            self.shortest_path_text.setText(' -> '.join(self.shortest_paths[(start, end)]))
        return

    def click_search_2(self):
        if self.start_edit_2.text().isdigit() == False or self.end_edit_2.text().isdigit() == False:
            self.shortest_path_length_text_2.setText('')
            self.shortest_path_text_2.setText('')
            return
        start = int(self.start_edit_2.text())
        end = int(self.end_edit_2.text())
        if start >= self.num_nodes_2 or end >= self.num_nodes_2:
            self.shortest_path_length_text_2.setText('')
            self.shortest_path_text_2.setText('')
            return
        if self.shortest_path_lengths_2[start, end] == float('inf'):
            length = 'inf'
            self.shortest_path_length_text_2.setText(str(length))
            self.shortest_path_text_2.setText('NO PATH')
        else:
            length = int(self.shortest_path_lengths_2[start, end])
            self.shortest_path_length_text_2.setText(str(length))
            self.shortest_path_text_2.setText(' -> '.join(self.shortest_paths_2[(start, end)]))
        return

    def click_search_3(self):
        if self.start_edit_3.text().isdigit() == False or self.end_edit_3.text().isdigit() == False:
            self.shortest_path_length_text_3.setText('')
            self.shortest_path_text_3.setText('')
            return
        start = int(self.start_edit_3.text())
        end = int(self.end_edit_3.text())
        if start >= self.num_nodes_3 or end >= self.num_nodes_3:
            self.shortest_path_length_text_3.setText('')
            self.shortest_path_text_3.setText('')
            return
        if self.shortest_path_lengths_3[start, end] == float('inf'):
            length = 'inf'
            self.shortest_path_length_text_3.setText(str(length))
            self.shortest_path_text_3.setText('NO PATH')
        else:
            length = int(self.shortest_path_lengths_3[start, end])
            self.shortest_path_length_text_3.setText(str(length))
            self.shortest_path_text_3.setText(' -> '.join(self.shortest_paths_3[(start, end)]))
        return

    def click_search_4(self):
        if self.start_edit_4.text().isdigit() == False or self.end_edit_4.text().isdigit() == False:
            self.shortest_path_length_text_4.setText('')
            self.shortest_path_text_4.setText('')
            return
        start = int(self.start_edit_4.text())
        end = int(self.end_edit_4.text())
        if start >= self.num_nodes_4 or end >= self.num_nodes_4:
            self.shortest_path_length_text_4.setText('')
            self.shortest_path_text_4.setText('')
            return
        if self.shortest_path_lengths_4[start, end] == float('inf'):
            length = 'inf'
            self.shortest_path_length_text_4.setText(str(length))
            self.shortest_path_text_4.setText('NO PATH')
        else:
            length = int(self.shortest_path_lengths_4[start, end])
            self.shortest_path_length_text_4.setText(str(length))
            self.shortest_path_text_4.setText(' -> '.join(self.shortest_paths_4[(start, end)]))
        return

if __name__ == '__main__':
    app = QApplication(sys.argv)  # 在 QApplication 方法中使用，创建应用程序对象
    extra = {

        # Button colors
        'search': '#17a2b8',

        # Font
        'font_family': 'Roboto',
    }
    apply_stylesheet(app, theme='light_blue.xml', extra=extra)
    # apply_stylesheet(app, theme='light_blue.xml')

    myWin = MyMainWindow()
    myWin.show()
    sys.exit(app.exec_())

