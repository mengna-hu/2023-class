import pickle

import networkx as nx
import random
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import ticker
from collections import Counter

random.seed(0)
DATA_NAME = '11_6'  # 11_6, 11_3, 11_5, 6
G = nx.read_gml(f'gml/t{DATA_NAME}.gml')

def getNumNodes(G):
    return G.number_of_nodes()
def getNumEdges(G):
    return G.number_of_edges()
def getAverageDegree(G):
    return sum(dict(G.degree()).values()) / G.number_of_nodes() / 2
def getShortestPath(G): # return 最短路长，最短路径，平均最短路径
    n = G.number_of_nodes()
    path_lengths = np.full((n, n), float('inf'))
    shortest_paths = {}
    count = 0
    sum_length = 0

    nodes = list(G.nodes())
    for u in range(n):
        for v in range(n):
            i, j = nodes[u], nodes[v]
            if nx.has_path(G, i, j):
                dij = nx.shortest_path_length(G, i, j)
                path = nx.shortest_path(G, i, j)
                shortest_paths[(u, v)] = path
                path_lengths[u, v] = dij
                count += 1
                sum_length += dij
    return path_lengths, shortest_paths, sum_length / count
def getCoreness(G):
    coreness = nx.core_number(G)
    return max(coreness.values())
def getAverageClusteringCoefficient(G):
    return nx.average_clustering(G)
def getAssortativityCoefficient(G):
    return nx.degree_assortativity_coefficient(G)

def Degree_distribution(G):
    degrees = dict(G.degree())
    degree_count = Counter(degrees.values())
    sorted_degree_count_dict = dict(sorted(degree_count.items(), key=lambda x: x[0]))

    print(sorted_degree_count_dict)

    k = list(sorted_degree_count_dict.keys())
    P = [count / G.number_of_nodes() for count in sorted_degree_count_dict.values()]  # 计算比例

    # # 绘制折线图
    plt.plot(k, P, marker='o', linestyle='-', color='#038355')
    # plt.bar(xi, yi)
    plt.xlabel('$k$')
    plt.ylabel('P($k$)')
    plt.title('Degree Distribution')
    plt.gca().yaxis.set_major_formatter(ticker.PercentFormatter(xmax=1))
    plt.savefig(rf"D:\Desktop\fig\{DATA_NAME}_degree_distribution.png")
    plt.show()

def Indegree_distribution(G):
    in_degrees = dict(G.in_degree())
    degree_count = Counter(in_degrees.values())
    sorted_degree_count_dict = dict(sorted(degree_count.items(), key=lambda x: x[0]))

    print(sorted_degree_count_dict)

    k = list(sorted_degree_count_dict.keys())
    P = [count / G.number_of_nodes() for count in sorted_degree_count_dict.values()]  # 计算比例

    # # 绘制折线图
    plt.plot(k, P, marker='o', linestyle='-', color='#038355') #248BD6 038355
    # plt.bar(xi, yi)
    plt.xlabel('$k$')
    plt.ylabel('P($k$)')
    plt.title('Indegree Distribution')
    plt.gca().yaxis.set_major_formatter(ticker.PercentFormatter(xmax=1))
    plt.savefig(rf"D:\Desktop\fig\{DATA_NAME}_indegree_distribution.png")
    plt.show()

def Outdegree_distribution(G):
    out_degrees = dict(G.out_degree())
    degree_count = Counter(out_degrees.values())
    sorted_degree_count_dict = dict(sorted(degree_count.items(), key=lambda x: x[0]))

    print(sorted_degree_count_dict)

    k = list(sorted_degree_count_dict.keys())
    P = [count / G.number_of_nodes() for count in sorted_degree_count_dict.values()]  # 计算比例

    # # 绘制折线图
    plt.plot(k, P, marker='o', linestyle='-', color='#038355')
    # plt.bar(xi, yi)
    plt.xlabel('$k$')
    plt.ylabel('P($k$)')
    plt.title('Outdegree Distribution')
    plt.gca().yaxis.set_major_formatter(ticker.PercentFormatter(xmax=1))
    plt.savefig(rf"D:\Desktop\fig\{DATA_NAME}_outdegree_distribution.png")
    plt.show()

def Shortest_path_length(G):
    if nx.is_strongly_connected(G):
        print('average path length: {}'.format(nx.average_shortest_path_length(G)))

    n = G.number_of_nodes()
    path_lengths = np.full((n, n), float('inf'))

    count = 0
    sum_length = 0

    nodes = list(G.nodes())
    for u in range(n):
        for v in range(n):
            i, j = nodes[u], nodes[v]
            if nx.has_path(G, i, j):
                dij = nx.shortest_path_length(G, i, j)
                path_lengths[u, v] = dij
                count += 1
                sum_length += dij

                # shortest_paths[(i, j)] = dij
                # print('Shortest path length from node {} to node {} is {}.'.format(i, j, dij))
            # else:
            #     print('No Shortest path length from node {} to node {}.'.format(i, j))

    print(path_lengths)
    print('average_shortest_path_length: ', sum_length / count)

def Clustering_efficient(G):
    print(nx.clustering(G))
    print(nx.average_clustering(G))

def Coreness(G):
    coreness = nx.core_number(G)
    print("节点核心度：")
    for node, c in coreness.items():
        print(f"节点 {node} 的核心度为：{c}")
    max_coreness = max(coreness.values())
    print(f'图的核心： {max_coreness}')
    nx.average_clustering(G)

def Assortativity_coefficient(G):
    print(nx.degree_assortativity_coefficient(G))

def Node_betweenness(G):
    betweenness_centrality = nx.betweenness_centrality(G)
    # 打印每个节点的介数中心性
    for node, betweenness in betweenness_centrality.items():
        print(f"Node {node}: {betweenness}")

def Edge_betweenness(G):
    # 计算边介数中心性
    edge_betweenness_centrality = nx.edge_betweenness_centrality(G)
    # 打印每条边的介数中心性
    for edge, betweenness in edge_betweenness_centrality.items():
        print(f"Edge {edge}: {betweenness}")

def betweenness_and_degree(G):
    # 计算节点介数中心性和度数
    betweenness_centrality = nx.betweenness_centrality(G)
    degree_centrality = dict(G.degree())

    # 绘制散点图
    x, y = zip(*[(degree_centrality[node], betweenness_centrality[node]) for node in G.nodes()])
    fig, ax = plt.subplots()
    ax.scatter(x, y, s=5)

    # 设置图标题和坐标轴标签
    ax.set_title('Node Betweenness and Degree')
    ax.set_xlabel('Node Degree')
    ax.set_ylabel('Node Betweenness')
    plt.savefig(rf"D:\Desktop\fig\{DATA_NAME}_betweenness_and_degree.png")
    # plt.show()


def cal_eff(graph): # 网络效率
    if graph.number_of_nodes() == 0 or graph.number_of_nodes() == 1:
        return 0
    nodes = list(graph.nodes())
    n = len(nodes)
    eff_list = [1./nx.shortest_path_length(graph, nodes[i],nodes[j]) for i in range(n)
                for j in range(n) if nx.has_path(graph, nodes[i],nodes[j]) and i!=j]
    av_eff = sum(eff_list)/(n*(n-1))
    return av_eff
def Average_shortest_length(graph):
    if graph.number_of_nodes() == 0:
        return float('inf')
    if nx.is_strongly_connected(graph) and graph.number_of_nodes() != 0:
        return nx.average_shortest_path_length(graph)

    n = graph.number_of_nodes()
    path_lengths = np.full((n, n), float('inf'))

    count = 0
    sum_length = 0

    nodes = list(graph.nodes())
    for u in range(n):
        for v in range(n):
            i, j = nodes[u], nodes[v]
            if nx.has_path(graph, i, j):
                dij = nx.shortest_path_length(graph, i, j)
                path_lengths[u, v] = dij
                count += 1
                sum_length += dij
    return sum_length / count
def calculate_remaining_size(graph):
    if graph.number_of_nodes() == 0:
        return 0
    largest_cc = max(nx.weakly_connected_components(graph), key=len)
    return len(largest_cc)

def randomAttack(G):
    results = []
    G_random_attack= G.copy()
    remove_cnt = 0
    while nx.number_of_nodes(G_random_attack) > 0:
        node_to_remove = random.choice(list(G_random_attack.nodes()))
        G_random_attack.remove_node(node_to_remove)
        remove_cnt += 1
        remaining_size = calculate_remaining_size(G_random_attack)
        results.append((remove_cnt / G.number_of_nodes(), remaining_size))

    with open(f'results/random_attack_S_{DATA_NAME}.pkl', 'wb') as f:
        pickle.dump(results, f)

    ratios = [result[0] for result in results]
    sizes = [result[1] / G.number_of_nodes() for result in results]

    plt.scatter(ratios, sizes, s=5)
    plt.xlabel('$f$')
    plt.ylabel('$S$')
    plt.title('Random Attack')
    # plt.savefig(rf"D:\Desktop\fig\{DATA_NAME}_random_attack_S.png")
    plt.savefig(rf"D:\Desktop\fig{DATA_NAME}\random_attack_S.png")
    plt.show()

def randomAttackE(G):
    results = []
    G_random_attack= G.copy()
    remove_cnt = 0
    while nx.number_of_nodes(G_random_attack) > 0:
        node_to_remove = random.choice(list(G_random_attack.nodes()))
        G_random_attack.remove_node(node_to_remove)
        remove_cnt += 1
        efficiency = cal_eff(G_random_attack)
        results.append((remove_cnt / G.number_of_nodes(), efficiency))

    with open(f'results/random_attack_E_{DATA_NAME}.pkl', 'wb') as f:
        pickle.dump(results, f)

    ratios = [result[0] for result in results]
    sizes = [result[1] for result in results]

    plt.scatter(ratios, sizes, s=5)
    plt.xlabel('$f$')
    plt.ylabel('$E$')
    plt.title('Random Attack')
    # plt.savefig(rf"D:\Desktop\fig\{DATA_NAME}_random_attack_S.png")
    plt.savefig(rf"D:\Desktop\fig{DATA_NAME}\random_attack_E.png")
    plt.show()

def randomAttackL(G):
    results = []
    G_random_attack= G.copy()
    remove_cnt = 0
    while nx.number_of_nodes(G_random_attack) > 0:
        node_to_remove = random.choice(list(G_random_attack.nodes()))
        G_random_attack.remove_node(node_to_remove)
        remove_cnt += 1
        efficiency = Average_shortest_length(G_random_attack)
        results.append((remove_cnt / G.number_of_nodes(), efficiency))

    with open(f'results/random_attack_L_{DATA_NAME}.pkl', 'wb') as f:
        pickle.dump(results, f)

    ratios = [result[0] for result in results]
    sizes = [result[1] for result in results]

    plt.scatter(ratios, sizes, s=5)
    plt.xlabel('$f$')
    plt.ylabel('$L$')
    plt.title('Random Attack')
    # plt.savefig(rf"D:\Desktop\fig\{DATA_NAME}_random_attack_S.png")
    plt.savefig(rf"D:\Desktop\fig{DATA_NAME}\random_attack_L.png")
    plt.show()

def intentionalAttack(G):
    results = []
    G_intentional_attack = G.copy()
    remove_cnt = 0
    with open(f'results/intentional_all_nodes_{DATA_NAME}.pkl', 'rb') as f:
        all_nodes = pickle.load(f)
    while nx.number_of_nodes(G_intentional_attack) > 0:
        # 找到对网络影响最大的节点
        # node_to_remove = max(G_intentional_attack.nodes(),
        #                      key=lambda n: nx.algorithms.centrality.betweenness_centrality(G_intentional_attack)[n])
        node_to_remove = all_nodes[remove_cnt]
        G_intentional_attack.remove_node(node_to_remove)
        remove_cnt += 1
        remaining_size = calculate_remaining_size(G_intentional_attack)
        results.append((remove_cnt / G.number_of_nodes(), remaining_size))
        # all_nodes.append(node_to_remove)

    with open(f'results/intentional_attack_S_{DATA_NAME}.pkl', 'wb') as f:
        pickle.dump(results, f)


    ratios = [result[0] for result in results]
    sizes = [result[1]/G.number_of_nodes() for result in results]

    plt.scatter(ratios, sizes, s=5)
    plt.xlabel('$f$')
    plt.ylabel('$S$')
    plt.title('Intentional Attack')
    plt.savefig(rf"D:\Desktop\fig{DATA_NAME}\intentional_attack_S.png")
    plt.show()

def intentionalAttackE(G):
    results = []
    G_intentional_attack = G.copy()
    remove_cnt = 0
    with open(f'results/intentional_all_nodes_{DATA_NAME}.pkl', 'rb') as f:
        an=pickle.load(f)
    while nx.number_of_nodes(G_intentional_attack) > 0:
        # 找到对网络影响最大的节点
        # node_to_remove = max(G_intentional_attack.nodes(),
        #                      key=lambda n: nx.algorithms.centrality.betweenness_centrality(G_intentional_attack)[n])
        node_to_remove = an[remove_cnt]
        G_intentional_attack.remove_node(node_to_remove)
        remove_cnt += 1
        remaining_size = cal_eff(G_intentional_attack)
        results.append((remove_cnt / G.number_of_nodes(), remaining_size))

    with open(f'results/intentional_attack_E_{DATA_NAME}.pkl', 'wb') as f:
        pickle.dump(results, f)


    ratios = [result[0] for result in results]
    sizes = [result[1]/G.number_of_nodes() for result in results]

    plt.scatter(ratios, sizes, s=5)
    plt.xlabel('$f$')
    plt.ylabel('$E$')
    plt.title('Intentional Attack')
    plt.savefig(rf"D:\Desktop\fig{DATA_NAME}\intentional_attack_E.png")
    plt.show()

def intentionalAttackL(G):
    results = []
    G_intentional_attack = G.copy()
    remove_cnt = 0
    all_nodes = []
    while nx.number_of_nodes(G_intentional_attack) > 0:
        # 找到对网络影响最大的节点
        node_to_remove = max(G_intentional_attack.nodes(),
                             key=lambda n: nx.algorithms.centrality.betweenness_centrality(G_intentional_attack)[n])
        G_intentional_attack.remove_node(node_to_remove)
        remove_cnt += 1
        remaining_size = Average_shortest_length(G_intentional_attack)
        results.append((remove_cnt / G.number_of_nodes(), remaining_size))
        all_nodes.append(node_to_remove)

    with open(f'results/intentional_attack_L_{DATA_NAME}.pkl', 'wb') as f:
        pickle.dump(results, f)
    with open(f'results/intentional_all_nodes_{DATA_NAME}.pkl', 'wb') as f:
        pickle.dump(all_nodes, f)

    ratios = [result[0] for result in results]
    sizes = [result[1]/G.number_of_nodes() for result in results]

    plt.scatter(ratios, sizes, s=5)
    plt.xlabel('$f$')
    plt.ylabel('$L$')
    plt.title('Intentional Attack')
    plt.savefig(rf"D:\Desktop\fig{DATA_NAME}\intentional_attack_L.png")
    plt.show()

