If you want to get some properties of the network, you need to call functions from utils.py. 
Folder 'csv_data' is original data and generate_network.py generates networks with them to Folder 'gml'.  
Folder 'gml' contains 4 networks: t11_6 to Network-1, t11_3 to Network-2, t11_5 to Network-3, t11_6 to Network-4. 
Running implement.py can obtain the interface. 