import networkx as nx
import pandas as pd

DATA_NAME = '6'  # 11_6, 11_3, 11_5, 6

G = nx.DiGraph()

# 读取node
node_data = pd.read_csv(f'csv_data/{DATA_NAME}.csv/nodes.csv') # f'csv/Nodes_t{DATA_NAME}.csv'
node_data = node_data.fillna(-3)
# print(node_data.columns)
for index, row in node_data.iterrows():
    node_id = str(row['# index'])
    # colegio = int(row.iloc[2])
    curso = int(row[' Curso'])
    grupo = str(row[' Grupo'])
    sexo = str(row[' Sexo'])
    prosocial = float(row[' prosocial'])
    crttotal = int(row[' crttotal'])
    node_attributes = {
        # 'Colegio': colegio,
        'Curso': curso,
        'Grupo': grupo,
        'Sexo': sexo,
        'prosocial': prosocial,
        'crttotal': crttotal,
    }
    G.add_node(node_id, **node_attributes)

# 读取edge
edge_data = pd.read_csv(f'csv_data/{DATA_NAME}.csv/edges.csv') # f'csv/Edges_t{DATA_NAME}.csv'
edge_data = edge_data.fillna(-3)
# print(edge_data.columns)
for index, row in edge_data.iterrows():
    source = str(row['# source'])
    target = str(row[' target'])
    # id = int(row.iloc[2])
    weight = int(row[' weight'])
    G.add_edge(source, target, weight=weight)

# 保存network
nx.write_gml(G, f'gml/t{DATA_NAME}.gml')
